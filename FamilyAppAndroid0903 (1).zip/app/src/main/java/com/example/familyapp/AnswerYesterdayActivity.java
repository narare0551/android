package com.example.familyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AnswerYesterdayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer_yesterday);
    }
}