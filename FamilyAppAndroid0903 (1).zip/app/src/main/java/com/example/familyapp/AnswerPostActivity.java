package com.example.familyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AnswerPostActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer_post);
    }
}